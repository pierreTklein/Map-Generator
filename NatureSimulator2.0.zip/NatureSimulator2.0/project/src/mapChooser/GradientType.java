package mapChooser;

public enum GradientType {
	SMOOTH,
	DISCRETE,
}
